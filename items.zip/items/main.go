package main

import (
	"items/app"
)

func main() {
	app.StartRoute()
}
